# Gaon Delivery Android demo

## Build APK using GitHub from a phone
1. Create a GitHub repository named `gaon-delivery`.
2. Upload the CONTENTS of this ZIP to the repository, preserving the `app` and `.github` folders. Do not upload just the ZIP file.
3. Open the repository's Actions tab and enable workflows if prompted.
4. Choose `Build Gaon Delivery APK` and tap `Run workflow`, or push to `main` to trigger a build.
5. After the run finishes with a green check, open the run and download the `Gaon-Delivery-APK` artifact.
6. Extract the downloaded artifact ZIP. It contains `app-debug.apk`; tap it to install.

Important: this is a demo app with sample products and a demo-only checkout. It is not connected to a real shop or delivery backend. The APK is a debug build for testing, not a Play Store release.
